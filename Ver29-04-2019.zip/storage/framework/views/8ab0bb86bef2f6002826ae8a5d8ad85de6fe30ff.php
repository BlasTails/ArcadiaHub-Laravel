<?php $__env->startSection('content'); ?>
        <header class="masthead">
            <div class="container d-flex h-100 align-items-center">
                <div class="mx-auto text-center">
                    <h1 class="mx-auto my-0 text-">ArcadiaHub</h1> <br/><br/><br/><br/>
                    <h2 class="text-black-50 mx-auto mt-2 mb-5">Seek, Reach, Connect</h2>
                    <a href="homepage.html"><button type="submit" class="registerbtn">About</button></a>
                    <br/><br/><br/><br/><br/><br/><br/>
                </div>
            </div>
        </header>
        <!-- Footer  -->
        <footer class="bg-black small text-center text-white-50">
            <div class="container">
                Copyright &copy; Your Website 2019
            </div>
        </footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/pages/index.blade.php ENDPATH**/ ?>